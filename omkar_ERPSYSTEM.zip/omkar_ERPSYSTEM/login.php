<?php
session_start();
if (isset($_SESSION['unique_id'])) {
  include_once "php/config.php";
  $sqlul = mysqli_query($conn, "SELECT * FROM users WHERE unique_id = {$_SESSION['unique_id']}");
  if (mysqli_num_rows($sqlul) > 0) {
    $rowul = mysqli_fetch_assoc($sqlul);
  }
  if ($rowul['role'] == 'Student') {
    header("location: Student.php");
  } else if ($rowul['role'] == 'Faculty') {
    header("location: Faculty.php");
  }
}
?>
<html>

<head>
  <title>Login Form</title>
</head>

<body>
  <div class="container">
    <section class="login-content">
      <div class="form login">
        <form action="#" method="POST" enctype="multipart/form-data" autocomplete="off">
          <h2  class="title">Login</h2>
          <div class="error-text"></div>
          <div class="field input">
            <label class="text">Email Address</label>
            <input type="text" name="email" placeholder="Enter your email" required>
          </div>
          <div class="field input">
            <label class="text">Password</label>
            <input type="password" name="password" placeholder="Enter your password" required>
            <i class="fas fa-eye"></i>
          </div>
          <div class="field input">
            <label class="text">Choose the Role</label>
            <select class="select1" id="select1" name="select1" onfocus="give()" onchange="give()" required>
              <option value="Student">Student</option>
              <option value="Faculty">Faculty</option>
          </div>
          </select>
          <div class="field button">
            <input type="submit" name="submit" value="Login">
          </div>
        </form>
        <div><a href="index.php">Not yet signed up?</a></div>
    </section>
  </div>
  </div>
  <script src="javascript/pass-show-hide.js"></script>
  <script src="javascript/login.js"></script>

</body>

</html>