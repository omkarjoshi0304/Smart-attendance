<?php
function calculatePresentPercentage($name) {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "chatapp";

    // Array of table names to query
    $tables = ['maths', 'physics', 'chemistry','bee','ema']; // Add more tables as needed
    
    // Initialize counters
    $totalColumns = 0;
    $presentCount = 0;

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Loop through each table and count "present" occurrences for the given Name
    foreach ($tables as $table) {
        // Build the query dynamically
        $query = "SELECT * FROM $table WHERE Name = ?";

        // Prepare and bind parameter
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $name);

        // Execute the query
        $stmt->execute();

        // Get result set
        $result = $stmt->get_result();

        // Fetch each row and count "present"
        while ($row = $result->fetch_assoc()) {
            foreach ($row as $key => $value) {
                // Check if the column contains "present"
                if (stripos($value, 'present') !== false) {
                    $presentCount++;
                }
                // Count total columns checked
                $totalColumns++;
            }
        }

        // Close statement
        $stmt->close();
    }

    // Close connection
    $conn->close();
    //================================================
    //It gives count of total column including Name coulmn also
    $tableCount = count($tables);
    $totalColumnsPresent =  $totalColumns-$tableCount;
    //=============================================
    
    // Calculate percentage
    if ($totalColumnsPresent > 0) {
        $percentage = ($presentCount /$totalColumnsPresent) * 100;
    } else {
        $percentage = 0; // Avoid division by zero
    }

    // Return the percentage
    return $percentage;
}
?>
